import sys
from const import EXIT
from command_parser import executeCommand


def commandMode(parkingLot):
    try:
        command = input().split()
        while command[0] != EXIT:
            parkingLot = executeCommand(parkingLot, command)
            command = input().split()
    except Exception as e:
        print(e)


def fileReaderMode(parkingLot, fileName):
    try:
        with open(fileName) as file:
            commands = file.readlines()
            for command in commands:
                parkingLot = executeCommand(
                    parkingLot, command.replace('\n', '').split())
    except Exception as e:
        print(e)


def main():
    parkingLot = None
    if len(sys.argv) > 1:
        fileReaderMode(parkingLot, sys.argv[1])
    else:
        commandMode(parkingLot)


if __name__ == '__main__':
    main()
