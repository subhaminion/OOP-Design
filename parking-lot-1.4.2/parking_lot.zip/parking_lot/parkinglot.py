class ParkingLot:
    """
    Parking Lot Class
    """

    def __init__(self, size):
        """
        Parking Lot Constructor
        ARGS:
            size (integer) -> size of the parking lot
        """
        self.parked_cars = 0
        self.slots = dict.fromkeys([i for i in range(1, int(size) + 1)])

    def add_cars(self):
        """
        Adds cars to the parking lot, will increment parked cars number
        """
        self.parked_cars += 1

    def remove_cars(self):
        """
        Removed cars from the parking lot, will decreent parked cars number
        """
        self.parked_cars -= 1

    def get_slots(self):
        """
        getter for parking lots
        """
        return self.slots

    def set_slots(self, slot, value):
        """
        setter for parking slots
        ARGS:
            slot(integer) -> where to place the incoming value
            value(NoneType or Car Object) -> for setting the value on the given slot
        """
        self.slots[slot] = value

    def get_parked_cars(self):
        """
        getter for number of cars parked
        """
        return self.parked_cars
