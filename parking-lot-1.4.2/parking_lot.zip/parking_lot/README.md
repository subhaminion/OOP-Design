# Go-Jek Assignment By Subham Bhattacharjee

## 1. Solution Approach
	A car consist of Registration number, slot number and it's color. Likewise our Parking Lot consist slots. For not making it too complicated, I choose a python dictionary for storing cars on slots and implemented the functionalities as accordingly.

## 2. Supported Commands

	- `create_parking_lot` <`n`>   
	To create a Parking lot. Where `n` is the size of the parking lot

	- `park` <`registration_number`> <`color`>   
	To park the car in the parking lot and prints the allocated slot in the parking lot. Where `registration_number` is given registration number for the car and `color` is given color for the car

	- `leave` <`slot`>   
	To leave the parking lot from desired slot and prints the leaving slot. given slot number. Where `slot` is given sloat number

	- `status`   
	To check the status of Parking Lot

	- `slot_numbers_for_cars_with_color` <`color`>   
	To prints the registration number of the cars for the given color. Where `color` is given color

	- `slot_number_for_registration_number` <`registration_number`>   
	prints the slot number of the cars for the given number. Where `registration_number` is given registration number.

	- `registration_numbers_for_cars_with_color` <`color`>   
	To prints the slot number of the cars for the given color.  Where `color` is given color.

## 3. Running Application
#### 3.1 Running the application in File mode:

	```python
	 python main.py input.txt
	```

#### 3.2 Running the application in Interactive mode:

	```python
	 python main.py
	```

#### 3.3 Running the application with test and input file:
	```python
	sh bin/parking_lot
	```

## 4 For running the tests
	```python
	python Tests.py
	```
#### 4.1 Test Cases
	- Total number of test cases - 14
	- Over All Code coverage - 91%

#### 4.2 File Wise Code Coverage
	Name            Stmts   Miss  Cover
	-----------------------------------
	car.py             13      0   100%
	parkinglot.py      14      0   100%
	tests.py           65      0   100%
	utils.py           99     17    83%
	-----------------------------------
	TOTAL             191     17    91%
