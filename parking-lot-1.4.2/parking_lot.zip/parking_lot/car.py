class Car:
    """
    Car Class
    """

    def __init__(self, registration_number, color):
        """
        Car object constructor
        ARGS:
            registration_number -> (string)
            color -> (string)
        """
        self.car_registration_number = registration_number
        self.car_color = color
        self.car_slot = None

    def set_slot(self, slot):
        """
        setter for slot
        ARGS:
            slot -> (integer)
        """
        self.car_slot = slot

    def get_slot(self):
        """
        getter for slot
        """
        return self.car_slot

    def get_registration_number(self):
        """
        getter for registration number
        """
        return self.car_registration_number
    def get_color(self):
        """
        getter for color
        """
        return self.car_color