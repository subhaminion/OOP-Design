from parkinglot import ParkingLot
from car import Car


def create_parking_lot(size):
    """
    Creates parking lot
    ARGS:
        size(int) -> size of the parking lot
    """
    parking_lot = ParkingLot(int(size))
    print("Created a parking lot with " + size + "slots")
    return parking_lot


def is_parking_lot_full(parking_lot):
    """
    Checks if parking lot is full or not
    ARGS:
        parking_lot -> ParkingLot Object
    """
    return len(parking_lot.get_slots()) <= parking_lot.get_parked_cars()


def park_car(parking_lot, registration_number, color):
    """
    will park the car in parking lot and prints the allocated slot in the parking lot
    ARGS:
        parkinglit(object) -> Parkig Lot Object
        registration_number(string) -> registration number of the car
        color(string) -> given color of the car
    """
    return_string = ''
    if parking_lot:
        if not is_parking_lot_full(parking_lot):
            parking_slot = parking_lot.get_slots()
            for slot in parking_slot:
                if parking_slot[slot] is None:
                    car = Car(registration_number, color)
                    parking_lot.set_slots(slot, car)
                    car.set_slot(slot)
                    parking_lot.add_cars()
                    return_string = 'Allocated slot number: ' + str(slot)
                    break
        else:
            return_string = "Sorry, Parking lot is Full!"
    else:
        return_string = "Parking lot is not defined"  #TODOL raise an exception
    return return_string


def car_departure(parking_lot, input_slot):
    """
    will leeve the parking lot from desired slot and prints the leaving slot
    ARGS:
        parkinglit(object) -> Parkig Lot Object
        input_slot(string) -> given slot number
    """
    return_string = ''
    if parking_lot:
        if not parking_lot.get_parked_cars():
            return_string = 'Sorry, parking lot is empty'
        elif int(input_slot) >= 1 and int(input_slot) <= len(parking_lot.get_slots()):
            parking_slot = parking_lot.get_slots()
            value = parking_slot.get(int(input_slot), None)
            if value is not None:
                parking_lot.set_slots(int(input_slot), None)
                parking_lot.remove_cars()
                return_string = 'Slot number ' + input_slot + ' is free'
            else:
                return_string = 'No car at Slot number ' + input_slot
        else:
            return_string = 'Cannot exit slot: ' + input_slot + ' as no such exist!'
    else:
        return_string = 'Parking lot is not defined'
    return return_string


def parking_lot_status(parking_lot):
    """
    returns the status of Parking Lot
    ARGS:
        parking_lot -> parking lot object
    """
    return_string = ''
    if parking_lot:
        print('Slot No.\tRegistration No\tColour')
        parking_slot = parking_lot.get_slots()
        for parked_car in parking_slot.values():
            if parked_car is not None:
                    return_string += str(parked_car.get_slot()) + '\t' + \
                    parked_car.get_registration_number() + '\t' + \
                    parked_car.get_color() + '\n'
    else:
        return_string = "parking lot is not defined"
    return return_string


def car_by_color(parking_lot, input_color):
    """
    prints the registration number of hte cars for the fiven color
    ARGS:
        parking_lot -> parking lot object
        input_color(str) -> given color
    """
    return_string = ""
    if parking_lot:
        if not parking_lot.get_parked_cars():
            return_string = 'Sorry, parking lot is empty'
        else:
            flag = False
            parking_slot = parking_lot.get_slots()
            for parked_car in parking_slot.values():
                if parked_car is not None:
                    if parked_car.get_color() == input_color:
                        flag = True
                        return_string += parked_car.get_registration_number() + ', '
            if not flag:
                return_string = 'Not found'
    else:
        return_string = 'Parking lot is not defined'
    return return_string


def slot_by_color(parking_lot, input_color):
    """
    prints the slot number of the cars for the given colour
    ARGS:
        parking_lot(ParkingLot Object)
        input_color(str) - given colour
    """
    return_string = ""
    if parking_lot:
        if not parking_lot.get_parked_cars():
            return_string = "Sorry, Parking lot is empty"
        else:
            flag = False
            parking_slot = parking_lot.get_slots()
            for parked_car in parking_slot.values():
                if parked_car is not None:
                    if parked_car.get_color() == input_color:
                        flag = True
                        return_string += str(parked_car.get_slot()) + ', '
            if not flag:
                return_string = "Not found"
    else:
        return_string = "Parking lot is not defined"
    return return_string


def slot_by_car_number(parking_lot, number):
    """
    prints the slot number of the cars for the given number
    ARGS:
        parking_lot(ParkingLot Object)
        number(str) - given registration number
    """
    return_string = ''
    if parking_lot:
        if not parking_lot.get_parked_cars():
            return_string = 'Sorry, parking lot is empty'
        else:
            flag = False
            parking_slot = parking_lot.get_slots()
            for parked_car in parking_slot.values():
                if parked_car is not None:
                    if parked_car.get_registration_number() == number:
                        flag = True
                        return_string += str(parked_car.get_slot()) + ', '
                        # assuming that for the cars, there is one and only one registration number exits
                        break
            if not flag:
                return_string = 'Not found'
    else:
        return_string = 'Parking lot is not defined'
    return return_string