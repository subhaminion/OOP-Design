import unittest
from utils import (
    create_parking_lot, park_car, is_parking_lot_full,
    car_departure, car_by_color, slot_by_color,
    slot_by_car_number
)


class TestParkingLotUtilities(unittest.TestCase):
    """
    will test the endpoints
    """

    def test_create_parking_lot(self):
        test_parking_lot = create_parking_lot(str(6))
        self.assertEqual(len(test_parking_lot.get_slots()), 6)

    def test_parking_lot_is_full(self):
        test_parking_lot = create_parking_lot(str(6))
        self.assertEqual(is_parking_lot_full(test_parking_lot), False)

    def test_park_car_lot_not_defined(self):
        test_string = park_car(None, 'KA-01-AA-1111', 'White')
        self.assertEqual('Parking lot is not defined', test_string)

    def test_park_car_lot_allocated(self):
        test_parking_lot = create_parking_lot(str(6))
        test_string = park_car(test_parking_lot, 'KA-01-AA-1112', 'White')
        self.assertEqual('Allocated slot number: 1', test_string)

    def test_park_car_lot_full(self):
        test_parking_lot = create_parking_lot(str(1))
        test_park_string = park_car(test_parking_lot, 'KA-01-AA-1112', 'White')
        test_string = park_car(test_parking_lot, 'KA-01-AA-1113', 'White')
        self.assertEqual('Sorry, Parking lot is Full!', test_string)

    def test_car_departure_empty(self):
        test_parking_lot = create_parking_lot(str(6))
        test_string = car_departure(test_parking_lot, '1')
        self.assertEqual('Sorry, parking lot is empty', test_string)

    def test_car_departure_free(self):
        test_parking_lot = create_parking_lot(str(6))
        test_park_string = park_car(test_parking_lot, 'KA-01-AA-1114', 'White')
        test_string = car_departure(test_parking_lot, '1')
        self.assertEqual('Slot number 1 is free', test_string)

    def test_car_departure_cannot_exit(self):
        test_parking_lot = create_parking_lot(str(6))
        test_park_string = park_car(test_parking_lot, 'KA-01-AA-1115', 'White')
        test_string = car_departure(test_parking_lot, '7')
        self.assertEqual('Cannot exit slot: 7 as no such exist!', test_string)

    def test_car_departure_slot_free(self):
        test_parking_lot = create_parking_lot(str(6))
        test_park_string = park_car(test_parking_lot, 'KA-01-AA-1116', 'White')
        test_string = car_departure(test_parking_lot, '2')
        self.assertEqual('No car at Slot number 2', test_string)

    def test_car_departure_not_defined(self):
        test_string = car_departure(None, '1')
        self.assertEqual('Parking lot is not defined', test_string)

    def test_car_by_color(self):
        test_parking_lot = create_parking_lot(str(6))
        test_park_string = park_car(test_parking_lot, 'KA-01-AA-1117', 'White')
        test_string = car_by_color(test_parking_lot, 'White')
        self.assertEqual(test_string, 'KA-01-AA-1117, ')

    def test_slot_by_car_number_not_found(self):
        test_parking_lot = create_parking_lot(str(6))
        test_park_string = park_car(test_parking_lot, 'KA-01-AA-1118', 'White')
        test_string = slot_by_car_number(test_parking_lot, 'KA-01-AA-1113')
        self.assertEqual(test_string, 'Not found')

    def test_slot_by_car_number(self):
        test_parking_lot = create_parking_lot(str(6))
        test_park_string = park_car(test_parking_lot, 'KA-01-AA-1103', 'White')
        test_string = slot_by_car_number(test_parking_lot, 'KA-01-AA-1103')
        self.assertEqual(test_string, '1, ')

    def test_slot_by_color(self):
        test_parking_lot = create_parking_lot(str(6))
        test_park_string = park_car(test_parking_lot, 'KA-01-AA-1119', 'White')
        test_string = slot_by_color(test_parking_lot, 'White')
        self.assertEqual(test_string, '1, ')


if __name__ == '__main__':
    unittest.main()
