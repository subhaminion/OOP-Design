from const import *
from utils import (
    create_parking_lot, park_car,
    car_departure, parking_lot_status, car_by_color,
    slot_by_car_number, slot_by_color
)


def executeCommand(parking_lot, command):
    if command[0] == CREATE_PARKING_LOT:
        parking_lot = create_parking_lot(command[1])
    elif command[0] == PARK_CAR:
        print(park_car(parking_lot, command[1], command[2]))
    elif command[0] == CAR_DEPARTURE:
        print(car_departure(parking_lot, command[1]))
    elif command[0] == LOT_STATUS:
        print(parking_lot_status(parking_lot).rstrip('\n'))
    elif command[0] == SEARCH_SLOT_BY_CAR_NUMBER:
        print(slot_by_car_number(parking_lot, command[1]).rstrip(', '))
    elif command[0] == SEARCH_CAR_BY_COLOUR:
        print(car_by_color(parking_lot, command[1]).rstrip(', '))
    elif command[0] == SEARCH_SLOT_BY_COLOUR:
        print(slot_by_color(parking_lot, command[1]).rstrip(', '))
    else:
        print('Command is not applicable')
    return parking_lot
